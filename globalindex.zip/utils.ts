
import { CountryIndexData, Country } from './types';

export const normalizeValue = (key: keyof CountryIndexData, val: number): number => {
  switch (key) {
    case 'freedom':
    case 'democracy':
    case 'civilLiberty':
      return val * 10;
    case 'education':
      return val * 100;
    default:
      return val;
  }
};

export const calculateOverallIndex = (indices: CountryIndexData): { score: number, missingCount: number } => {
  const keys: (keyof CountryIndexData)[] = [
    'freedom', 'democracy', 'safety', 'costOfLiving', 'healthCare', 'education', 'civilLiberty'
  ];
  
  let total = 0;
  let count = 0;
  let missing = 0;

  keys.forEach(key => {
    const val = indices[key];
    if (val !== null && val !== undefined) {
      total += normalizeValue(key, val);
      count++;
    } else {
      missing++;
    }
  });

  return {
    score: count > 0 ? total / count : 0,
    missingCount: missing
  };
};

export const calculateGlobalAverages = (countries: Country[]): Record<keyof CountryIndexData, number> => {
  const keys: (keyof CountryIndexData)[] = [
    'freedom', 'democracy', 'safety', 'costOfLiving', 'healthCare', 'education', 'civilLiberty'
  ];
  
  const results: any = {};
  
  keys.forEach(key => {
    let sum = 0;
    let count = 0;
    countries.forEach(c => {
      const val = c.indices[key];
      if (val !== null && val !== undefined) {
        sum += val;
        count++;
      }
    });
    results[key] = count > 0 ? sum / count : 0;
  });
  
  return results;
};
