
import React, { useState, useMemo, useEffect } from 'react';
import { COUNTRIES, SOURCES } from './constants';
import { Country, CountryIndexData } from './types';
import CountryCard from './components/CountryCard';
import CountryProfile from './components/CountryProfile';
import ComparisonView from './components/ComparisonView';
import { calculateOverallIndex, calculateGlobalAverages } from './utils';

type SortType = 'az' | 'za' | 'highest' | 'lowest' | string;

const App: React.FC = () => {
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const [sortType, setSortType] = useState<SortType>('az');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDark, setIsDark] = useState(true);

  // Calculate global averages once
  const globalAverages = useMemo(() => calculateGlobalAverages(COUNTRIES), []);

  // Filter out meta-sources and only keep actual index metrics
  const indexMetrics = useMemo(() => 
    SOURCES.filter(s => !['Country Profile Data (FAO Members)', 'General Knowledge & Profiles (Wikipedia)'].includes(s.name)), 
  []);

  // Issue Form State
  const [issueName, setIssueName] = useState('');
  const [issueEmail, setIssueEmail] = useState('');
  const [issueSubject, setIssueSubject] = useState('');
  const [issueMessage, setIssueMessage] = useState('');

  // Sync dark mode class
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleCompare = (country: Country) => {
    setCompareList(prev => 
      prev.includes(country.id) 
        ? prev.filter(id => id !== country.id)
        : [...prev, country.id]
    );
  };

  const isFormValid = useMemo(() => {
    return (
      issueEmail.trim().length > 0 &&
      issueEmail.includes('@') &&
      issueSubject.trim().length > 0 &&
      issueMessage.trim().length > 0
    );
  }, [issueEmail, issueSubject, issueMessage]);

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;

    const body = `Name: ${issueName || 'Anon'}\nEmail: ${issueEmail}\n\n${issueMessage}`;
    const mailtoLink = `mailto:usingaiformemes@gmail.com?subject=${encodeURIComponent(issueSubject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    
    // Reset fields
    setIssueName('');
    setIssueEmail('');
    setIssueSubject('');
    setIssueMessage('');
  };

  const comparingCountries = useMemo(() => 
    COUNTRIES.filter(c => compareList.includes(c.id)), 
  [compareList]);

  const filteredAndSortedCountries = useMemo(() => {
    // Basic filter: Exclude countries without any available indices
    let data = COUNTRIES.filter(c => {
      const { missingCount } = calculateOverallIndex(c.indices);
      return missingCount < 7; // Total indices is 7
    });

    // Search filter
    data = data.filter(c => 
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      c.officialName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.code.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    // Qualification check for overall index ranking
    if (sortType === 'highest' || sortType === 'lowest') {
      data = data.filter(c => calculateOverallIndex(c.indices).missingCount < 2);
    }
    
    // Qualification check for sub-indices
    if (sortType.includes('_')) {
        const [metricKey] = sortType.split('_') as [keyof CountryIndexData, string];
        data = data.filter(c => c.indices[metricKey] !== null);
    }

    return data.sort((a, b) => {
      const scoreA = calculateOverallIndex(a.indices).score;
      const scoreB = calculateOverallIndex(b.indices).score;

      if (sortType === 'az') return a.name.localeCompare(b.name);
      if (sortType === 'za') return b.name.localeCompare(a.name);
      
      if (sortType === 'highest') return scoreB - scoreA;
      if (sortType === 'lowest') return scoreA - scoreB;
      
      // Handle sub-index sorts
      if (sortType.includes('_')) {
        const [metricKey, direction] = sortType.split('_') as [keyof CountryIndexData, 'high' | 'low'];
        const valA = a.indices[metricKey] ?? -Infinity;
        const valB = b.indices[metricKey] ?? -Infinity;
        
        if (valA !== valB) {
            if (direction === 'high') return valB - valA;
            return valA - valB;
        }

        // Tiebreaker: Use overall index score if sub-index values are equal
        return scoreB - scoreA;
      }
      
      return 0;
    });
  }, [sortType, searchQuery]);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Navbar */}
      <nav className={`border-b sticky top-0 z-40 transition-colors duration-300 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-sky-600 rounded-xl flex items-center justify-center shadow-lg shadow-sky-200">
              <i className="fas fa-database text-white text-xl"></i>
            </div>
            <h1 className="text-2xl font-black tracking-tight italic">Global<span className="text-sky-500">Index</span></h1>
          </div>
          
          <div className="flex items-center gap-4 md:gap-8">
            <div className={`hidden md:flex items-center gap-8 text-sm font-bold ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              <a href="#profiles" className="hover:text-sky-500 transition-colors">Profiles</a>
              <a href="#report" className="hover:text-sky-500 transition-colors">Support</a>
            </div>
            
            <button 
              onClick={() => setIsDark(!isDark)}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isDark ? 'bg-slate-800 text-yellow-400 border border-slate-700' : 'bg-slate-100 text-slate-600 border border-slate-200'}`}
              aria-label="Toggle Dark Mode"
            >
              <i className={`fas ${isDark ? 'fa-sun' : 'fa-moon'}`}></i>
            </button>

            {compareList.length > 0 && (
              <button 
                onClick={() => setShowComparison(true)}
                className="bg-sky-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-sky-700 transition-all shadow-md shadow-sky-200 text-sm font-bold"
              >
                <i className="fas fa-columns"></i>
                Compare ({compareList.length})
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className={`py-12 md:py-20 transition-colors duration-300 px-4 ${isDark ? 'bg-slate-900' : 'bg-gradient-to-b from-white to-slate-50'}`}>
        <div className="max-w-7xl mx-auto text-center">
          <h2 className={`text-4xl md:text-6xl font-black mb-6 tracking-tight leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Country Index <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-sky-400">Rankings</span>
          </h2>
          <div className="space-y-6 max-w-2xl mx-auto">
            <div className="bg-red-600 text-white px-6 py-5 rounded-2xl shadow-2xl shadow-red-900/40 inline-block w-full border-4 border-red-500">
              <p className="text-sm font-black uppercase tracking-widest mb-1">
                <i className="fas fa-exclamation-triangle mr-2"></i> Disclaimer: This is not an official index.
              </p>
              <p className="text-xs font-bold leading-tight">
                This index is not endorsed by any authority.
              </p>
            </div>
            <p className="text-lg md:text-xl font-medium opacity-70 italic">
             An analysis of 7 indexes for a Global Index.
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="mt-10 max-w-2xl mx-auto relative px-4">
             <i className="fas fa-search absolute left-8 top-1/2 -translate-y-1/2 text-slate-400"></i>
             <input 
              type="text" 
              placeholder="Search by name or code..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-12 pr-6 py-4 rounded-2xl border text-lg shadow-xl focus:outline-none focus:ring-4 focus:ring-sky-500/20 transition-all ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'}`}
             />
          </div>
        </div>
      </header>

      {/* Formula Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className={`p-8 md:p-12 rounded-[2.5rem] shadow-xl border transition-colors duration-300 ${isDark ? 'bg-slate-900 border-slate-800 shadow-none' : 'bg-white border-slate-100 shadow-slate-200/50'}`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-sky-100 dark:bg-sky-900/30 rounded-full flex items-center justify-center text-sky-600">
              <i className="fas fa-calculator"></i>
            </div>
            <h3 className="text-2xl font-black">Methodology</h3>
          </div>
          <p className="opacity-70 font-medium mb-8 leading-relaxed max-w-3xl italic">
            Normalized 0-100 scale. Indexes highlighted in red have an index below 40 while indexes highlighted in green have an index above 70.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className={`p-4 rounded-2xl border transition-colors ${isDark ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-2">Normalization</h4>
              <ul className="text-sm font-semibold space-y-2">
                <li className="flex justify-between"><span>Freedom (0-10)</span> <span className="text-sky-500">x 10</span></li>
                <li className="flex justify-between"><span>Democracy (0-10)</span> <span className="text-sky-500">x 10</span></li>
                <li className="flex justify-between"><span>Civil Liberty (0-10)</span> <span className="text-sky-500">x 10</span></li>
              </ul>
            </div>
            <div className={`p-4 rounded-2xl border transition-colors ${isDark ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
              <h4 className="text-xs font-bold opacity-40 uppercase tracking-widest mb-2">Scaling</h4>
              <ul className="text-sm font-semibold space-y-2">
                <li className="flex justify-between"><span>Education (0-1)</span> <span className="text-sky-500">x 100</span></li>
                <li className="flex justify-between"><span>Safety (0-100)</span> <span className="text-sky-500">Raw</span></li>
                <li className="flex justify-between"><span>Health (0-100)</span> <span className="text-sky-500">Raw</span></li>
              </ul>
            </div>
            <div className="md:col-span-2 p-4 bg-sky-700 rounded-2xl flex flex-col justify-center text-white">
              <h4 className="text-xs font-bold opacity-80 uppercase tracking-widest mb-2">Final Formula</h4>
              <p className="text-2xl font-black font-mono">
                Overall Index = (Σ Normalized Indices) / N
              </p>
              <p className="text-xs opacity-80 mt-2">N = count of available data points.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Sources Section */}
      <section id="sources" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className={`p-8 md:p-12 rounded-[2.5rem] shadow-xl border transition-colors duration-300 ${isDark ? 'bg-slate-900 border-slate-800 shadow-none' : 'bg-white border-slate-100 shadow-slate-200/50'}`}>
          <div className="flex flex-col md:flex-row gap-12">
            <div className="md:w-1/3">
              <h3 className="text-3xl font-black mb-4 underline decoration-sky-500/30">Citations</h3>
              <p className="opacity-60 font-medium leading-relaxed text-sm italic">
                Sourced from multiple reliable sources.
              </p>
            </div>
            <div className="md:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SOURCES.map(source => (
                <a 
                  key={source.name}
                  href={source.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className={`flex items-center gap-4 p-4 rounded-2xl border transition-all group ${isDark ? 'bg-slate-800/50 border-slate-700 hover:bg-slate-800' : 'bg-slate-50 border-slate-100 hover:bg-sky-50 hover:border-sky-100'}`}
                >
                  <div className={`w-8 h-8 min-w-[32px] rounded-full flex items-center justify-center shadow-sm transition-colors ${isDark ? 'bg-slate-700 text-slate-400 group-hover:text-sky-400' : 'bg-white text-slate-400 group-hover:text-sky-600'}`}>
                    <i className="fas fa-external-link-alt text-[10px]"></i>
                  </div>
                  <span className={`text-xs font-bold transition-colors ${isDark ? 'text-slate-300 group-hover:text-sky-300' : 'text-slate-700 group-hover:text-sky-700'}`}>{source.name.split(' (')[0]}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid & Sorting */}
      <main id="profiles" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Ranking Disclaimers */}
        <div className={`mb-10 p-6 rounded-2xl border transition-all ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
          <h4 className="text-sm font-black uppercase tracking-widest text-sky-500 mb-3 italic">Data Rules & Inclusions</h4>
          <ul className="space-y-2 text-xs font-bold opacity-70 list-disc list-inside">
            <li>Countries without any available indexes are excluded from all views.</li>
            <li>For <span className="text-sky-500">Highest</span> and <span className="text-sky-500">Lowest</span> overall rankings, countries with 2 or more missing sub-indexes are excluded to maintain statistical integrity.</li>
            <li>For <span className="text-sky-500">Highest</span> and <span className="text-sky-500">Lowest</span> sub-index views, a <span className="italic underline">higher overall index score</span> serves as the primary tiebreaker for equal values.</li>
          </ul>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
          <div className="flex flex-col">
            <h3 className="text-2xl font-black italic">
              Nations <span className="opacity-40 text-sm not-italic ml-2">({filteredAndSortedCountries.length})</span>
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold opacity-50">Sort:</span>
            <select 
              value={sortType}
              onChange={(e) => setSortType(e.target.value)}
              className={`border rounded-xl px-4 py-2 text-sm font-bold transition-all focus:outline-none focus:ring-2 focus:ring-sky-500 ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-700'}`}
            >
              <optgroup label="General">
                <option value="az">A-Z</option>
                <option value="za">Z-A</option>
                <option value="highest">Highest Score</option>
                <option value="lowest">Lowest Score</option>
              </optgroup>
              
              {indexMetrics.map(metric => (
                <optgroup key={metric.key} label={metric.name.split(' (')[0]}>
                  <option value={`${metric.key}_high`}>Highest {metric.name.split(' (')[0]}</option>
                  <option value={`${metric.key}_low`}>Lowest {metric.name.split(' (')[0]}</option>
                </optgroup>
              ))}
            </select>
          </div>
        </div>

        {filteredAndSortedCountries.length === 0 ? (
          <div className="py-20 text-center opacity-40">
             <p className="text-xl font-black italic">No matches found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAndSortedCountries.map(country => (
              <CountryCard 
                key={country.id} 
                country={country} 
                onSelect={setSelectedCountry} 
                onToggleCompare={toggleCompare}
                isComparing={compareList.includes(country.id)}
                isDark={isDark}
                globalAverages={globalAverages}
              />
            ))}
          </div>
        )}
      </main>

      {/* Report Issue Form Section */}
      <section id="report" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <div className={`p-8 md:p-12 rounded-[2.5rem] shadow-xl border transition-colors duration-300 ${isDark ? 'bg-slate-900 border-slate-800 shadow-none' : 'bg-white border-slate-100 shadow-slate-200/50'}`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-sky-100 dark:bg-sky-900/30 rounded-full flex items-center justify-center text-sky-600">
              <i className="fas fa-bug"></i>
            </div>
            <h3 className="text-2xl font-black">Corrections</h3>
          </div>
          <p className="opacity-70 font-medium mb-8 leading-relaxed italic">
            Report errors below.
          </p>
          
          <form onSubmit={handleIssueSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input 
                type="text" 
                value={issueName}
                onChange={(e) => setIssueName(e.target.value)}
                placeholder="Name"
                className={`w-full px-5 py-4 rounded-xl border focus:ring-2 focus:ring-sky-500 ${isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'}`}
              />
              <input 
                type="email" 
                value={issueEmail}
                onChange={(e) => setIssueEmail(e.target.value)}
                placeholder="Email *"
                required
                className={`w-full px-5 py-4 rounded-xl border focus:ring-2 focus:ring-sky-500 ${isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'}`}
              />
            </div>
            <input 
              type="text" 
              value={issueSubject}
              onChange={(e) => setIssueSubject(e.target.value)}
              placeholder="Subject *"
              required
              className={`w-full px-5 py-4 rounded-xl border focus:ring-2 focus:ring-sky-500 ${isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'}`}
            />
            <textarea 
              rows={4}
              value={issueMessage}
              onChange={(e) => setIssueMessage(e.target.value)}
              placeholder="Message *"
              required
              className={`w-full px-5 py-4 rounded-xl border focus:ring-2 focus:ring-sky-500 resize-none ${isDark ? 'bg-slate-800 border-slate-700 text-white placeholder-slate-600' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'}`}
            ></textarea>
            <button 
              type="submit"
              disabled={!isFormValid}
              className={`w-full md:w-auto px-10 py-4 rounded-xl font-black transition-all shadow-lg active:scale-95 ${
                isFormValid 
                ? 'bg-sky-600 hover:bg-sky-700 text-white' 
                : 'bg-slate-300 dark:bg-slate-800 text-slate-500 opacity-50 cursor-not-allowed'
              }`}
            >
              Submit
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="pb-12 text-center opacity-40 text-[10px] font-bold px-4 uppercase tracking-widest italic">
        <p>© 2025 GlobalIndex Archive.</p>
      </footer>

      {/* Modals */}
      {selectedCountry && (
        <CountryProfile 
          country={selectedCountry} 
          onClose={() => setSelectedCountry(null)} 
          isDark={isDark}
          globalAverages={globalAverages}
        />
      )}

      {showComparison && (
        <ComparisonView 
          countries={comparingCountries}
          onClose={() => setShowComparison(false)}
          isDark={isDark}
          globalAverages={globalAverages}
        />
      )}
    </div>
  );
};

export default App;
