
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';
import { CountryIndexData } from '../types';
import { normalizeValue } from '../utils';

interface Props {
  data: CountryIndexData;
  isDark?: boolean;
}

const IndexRadarChart: React.FC<Props> = ({ data, isDark }) => {
  const chartData = [
    { subject: 'Freedom', A: normalizeValue('freedom', data.freedom || 0), fullMark: 100 },
    { subject: 'Democracy', A: normalizeValue('democracy', data.democracy || 0), fullMark: 100 },
    { subject: 'Safety', A: normalizeValue('safety', data.safety || 0), fullMark: 100 },
    { subject: 'Cost of Living', A: normalizeValue('costOfLiving', data.costOfLiving || 0), fullMark: 100 },
    { subject: 'Health Care', A: normalizeValue('healthCare', data.healthCare || 0), fullMark: 100 },
    { subject: 'Education', A: normalizeValue('education', data.education || 0), fullMark: 100 },
    { subject: 'Civil Liberty', A: normalizeValue('civilLiberty', data.civilLiberty || 0), fullMark: 100 },
  ];

  const gridColor = isDark ? '#334155' : '#e2e8f0';
  const textColor = isDark ? '#94a3b8' : '#64748b';
  const radarFill = '#0ea5e9'; // sky-500

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="65%" data={chartData}>
          <PolarGrid stroke={gridColor} />
          <PolarAngleAxis 
            dataKey="subject" 
            tick={{ fontSize: 10, fontWeight: 700, fill: textColor, fontStyle: 'italic' }}
          />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 8, fill: textColor }} stroke={gridColor} />
          <Radar
            name="Score"
            dataKey="A"
            stroke={radarFill}
            fill={radarFill}
            fillOpacity={isDark ? 0.2 : 0.4}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default IndexRadarChart;
