
import React from 'react';
import { Country, CountryIndexData } from '../types';
import { calculateOverallIndex, normalizeValue } from '../utils';
import { SOURCES } from '../constants';

interface Props {
  country: Country;
  onSelect: (country: Country) => void;
  onToggleCompare: (country: Country) => void;
  isComparing: boolean;
  isDark?: boolean;
  globalAverages: Record<keyof CountryIndexData, number>;
}

const CountryCard: React.FC<Props> = ({ country, onSelect, onToggleCompare, isComparing, isDark, globalAverages }) => {
  const { score, missingCount } = calculateOverallIndex(country.indices);
  const isHighOverall = score >= 70;
  const isLowOverall = score > 0 && score < 40;
  const isMissing = missingCount > 0;

  // Filter out meta-sources and only keep indices
  const indexSources = SOURCES.filter(s => 
    !['Country Profile Data (FAO Members)', 'General Knowledge & Profiles (Wikipedia)'].includes(s.name)
  );

  return (
    <div 
      className={`rounded-2xl shadow-sm border p-6 transition-all hover:shadow-md cursor-pointer group flex flex-col h-full 
        ${isDark ? 'bg-slate-900' : 'bg-white'} 
        ${isComparing ? 'border-sky-500 ring-2 ring-sky-500/20' : isDark ? 'border-slate-800 hover:border-slate-700' : 'border-slate-200 hover:border-sky-200'}
      `}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-4" onClick={() => onSelect(country)}>
          <img 
            src={country.flag} 
            alt={`${country.name} flag`} 
            className={`w-16 h-10 object-cover rounded-md border shadow-sm ${isDark ? 'border-slate-700' : 'border-slate-100'}`}
          />
          <div>
            <h3 className={`text-xl font-bold transition-colors ${isDark ? 'text-white group-hover:text-sky-400' : 'text-slate-900 group-hover:text-sky-600'}`}>{country.name}</h3>
            <p className="text-sm font-medium uppercase tracking-wider opacity-50">{country.code}</p>
          </div>
        </div>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onToggleCompare(country);
          }}
          className={`p-2 rounded-lg transition-colors ${isComparing ? 'bg-sky-600 text-white' : isDark ? 'bg-slate-800 text-slate-500 hover:bg-slate-700' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}
          title="Compare country"
        >
          <i className={`fas ${isComparing ? 'fa-check' : 'fa-plus'}`}></i>
        </button>
      </div>

      <div className="mb-4 flex-grow" onClick={() => onSelect(country)}>
        <div className="flex justify-between items-end mb-2">
          <span className="text-sm font-semibold opacity-60">Overall Index</span>
          <span className={`text-3xl font-black ${isHighOverall ? 'text-emerald-500' : isLowOverall ? 'text-red-500' : isDark ? 'text-sky-400' : 'text-sky-600'}`}>{score > 0 ? score.toFixed(1) : 'N/A'}</span>
        </div>
        <div className={`w-full rounded-full h-2.5 ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
          <div 
            className={`${isHighOverall ? 'bg-emerald-500' : isLowOverall ? 'bg-red-500' : 'bg-sky-500'} h-2.5 rounded-full transition-all duration-1000`} 
            style={{ width: `${score}%` }}
          ></div>
        </div>

        {/* 7 Individual Indices Scores */}
        <div className="mt-6 grid grid-cols-2 gap-x-4 gap-y-1.5 border-t pt-4 border-slate-100 dark:border-slate-800">
          {indexSources.map(source => {
            const val = country.indices[source.key];
            const normalized = val !== null ? normalizeValue(source.key, val) : 0;
            const isBelowAverageThreshold = val !== null && normalized < 40;
            const isAboveAverageThreshold = val !== null && normalized >= 70;

            let textColor = isDark ? 'text-slate-300' : 'text-slate-700';
            if (isAboveAverageThreshold) textColor = 'text-emerald-500';
            else if (isBelowAverageThreshold) textColor = 'text-red-500';

            return (
              <div key={source.name} className="flex justify-between items-center text-[10px]">
                <span className="opacity-50 font-bold truncate max-w-[85px]">{source.name.split(' (')[0]}</span>
                <span className={`font-black ${val === null ? 'text-slate-400' : textColor}`}>
                  {val !== null ? val : 'N/A'}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div onClick={() => onSelect(country)}>
        {isMissing && (
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold border ${isDark ? 'bg-red-950/20 text-red-400 border-red-900/50' : 'bg-red-50 text-red-600 border-red-100'}`}>
            <i className="fas fa-exclamation-triangle"></i>
            <span>({missingCount}) indexes missing</span>
          </div>
        )}
        
        {!isMissing && (
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold border ${isDark ? 'bg-sky-950/20 text-sky-400 border-sky-900/50' : 'bg-sky-50 text-sky-600 border-sky-100'}`}>
            <i className="fas fa-check-circle"></i>
            <span>Complete Dataset</span>
          </div>
        )}
      </div>

      <div className="mt-6 flex justify-between text-xs opacity-40 font-bold uppercase tracking-tight" onClick={() => onSelect(country)}>
        <span>Full Profile</span>
        <i className="fas fa-arrow-right opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all text-sky-500"></i>
      </div>
    </div>
  );
};

export default CountryCard;
