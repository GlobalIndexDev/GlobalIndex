
import React from 'react';
import { Country, CountryIndexData } from '../types';
import { SOURCES } from '../constants';
import { calculateOverallIndex, normalizeValue } from '../utils';

interface Props {
  countries: Country[];
  onClose: () => void;
  isDark?: boolean;
  globalAverages: Record<keyof CountryIndexData, number>;
}

const ComparisonView: React.FC<Props> = ({ countries, onClose, isDark, globalAverages }) => {
  const getMaxValue = (values: (number | null | undefined)[]): number => {
    const validValues = values.filter((v): v is number => typeof v === 'number' && !isNaN(v));
    return validValues.length > 0 ? Math.max(...validValues) : -Infinity;
  };

  const overallScores = countries.map(c => calculateOverallIndex(c.indices).score);
  const maxOverallScore = getMaxValue(overallScores);

  return (
    <div className={`fixed inset-0 z-50 overflow-auto flex flex-col animate-in slide-in-from-right duration-500 transition-colors ${isDark ? 'bg-slate-950 text-white' : 'bg-white text-slate-900'}`}>
      <header className={`border-b sticky top-0 z-30 px-6 py-4 flex items-center justify-between transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <h2 className="text-2xl font-black italic">Analytical Comparison <span className="text-sky-500">({countries.length})</span></h2>
        <button 
          onClick={onClose}
          className={`px-8 py-2 rounded-full font-bold transition-colors ${isDark ? 'bg-sky-600 text-white hover:bg-sky-500' : 'bg-slate-900 text-white hover:bg-slate-800'}`}
        >
          Exit Archive
        </button>
      </header>

      <div className="flex-grow p-6">
        <div className="min-w-max overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className={`p-4 text-left border-b-2 sticky left-0 z-20 min-w-[200px] transition-colors ${isDark ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>Comparison Criteria</th>
                {countries.map(c => (
                  <th key={c.id} className={`p-4 border-b-2 min-w-[250px] transition-colors ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'}`}>
                    <div className="flex items-center gap-3">
                      <img src={c.flag} alt={c.name} className={`w-10 h-7 object-cover rounded border ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />
                      <span className="text-xl font-black italic">{c.name}</span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {/* Profile Rows */}
              <tr>
                <td className={`p-4 font-bold opacity-50 sticky left-0 z-20 border-b transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>Official Designation</td>
                {countries.map(c => <td key={c.id} className={`p-4 border-b font-bold italic transition-colors ${isDark ? 'border-slate-800 text-slate-300' : 'border-slate-100 text-slate-800'}`}>{c.officialName}</td>)}
              </tr>
              <tr>
                <td className={`p-4 font-bold opacity-50 sticky left-0 z-20 border-b transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>Executive Head</td>
                {countries.map(c => (
                  <td key={c.id} className={`p-4 border-b font-medium transition-colors ${isDark ? 'border-slate-800 text-slate-300' : 'border-slate-100 text-slate-800'}`}>
                    {c.headOfStateWiki ? (
                      <a href={c.headOfStateWiki} target="_blank" rel="noopener noreferrer" className="text-sky-400 font-bold hover:underline">
                        {c.headOfState} <i className="fas fa-external-link-alt text-[8px]"></i>
                      </a>
                    ) : c.headOfState}
                  </td>
                ))}
              </tr>
              <tr>
                <td className={`p-4 font-bold opacity-50 sticky left-0 z-20 border-b-2 transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>Aggregated Overall Index</td>
                {countries.map((c, idx) => {
                  const score = overallScores[idx];
                  const isMax = score > 0 && score === maxOverallScore;
                  const isAboveThreshold = score >= 70;
                  const isBelowThreshold = score > 0 && score < 40;
                  
                  let colorClass = isDark ? 'text-sky-400' : 'text-sky-600';
                  if (isAboveThreshold) colorClass = 'text-emerald-500';
                  else if (isBelowThreshold) colorClass = 'text-red-500';
                  else if (isMax) colorClass = isDark ? 'text-sky-400' : 'text-sky-700';

                  return (
                    <td key={c.id} className={`p-4 border-b-2 transition-colors ${isDark ? 'border-slate-800' : 'border-slate-200'} ${isMax ? (isDark ? 'bg-sky-950/20' : 'bg-sky-100') : ''}`}>
                      <span className={`text-2xl font-black ${colorClass}`}>
                        {score > 0 ? score.toFixed(1) : 'N/A'}
                      </span>
                    </td>
                  );
                })}
              </tr>

              {/* Index Rows */}
              {SOURCES.filter(s => s.key !== 'freedom' || (s.name !== 'Country Profile Data (FAO Members)' && s.name !== 'General Knowledge & Profiles (Wikipedia)')).map(source => {
                const rowValues = countries.map(c => c.indices[source.key]);
                const maxInRow = getMaxValue(rowValues);

                return (
                  <tr key={source.name} className={`group transition-colors ${isDark ? 'hover:bg-slate-900' : 'hover:bg-slate-50'}`}>
                    <td className={`p-4 font-bold sticky left-0 z-20 border-b transition-colors ${isDark ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-100 text-slate-700'}`}>
                      {source.name.split(' (')[0]}
                    </td>
                    {countries.map((c, idx) => {
                      const val = rowValues[idx];
                      const isNull = val === null || val === undefined;
                      const isMax = !isNull && val === maxInRow;
                      const normalized = isNull ? 0 : normalizeValue(source.key, val!);
                      
                      const isBelowThreshold = !isNull && normalized < 40;
                      const isAboveThreshold = !isNull && normalized >= 70;

                      let textColor = isDark ? 'text-slate-200' : 'text-slate-900';
                      let barColor = 'bg-sky-500';

                      if (isAboveThreshold) {
                        textColor = 'text-emerald-500';
                        barColor = 'bg-emerald-500';
                      } else if (isBelowThreshold) {
                        textColor = 'text-red-500';
                        barColor = 'bg-red-500';
                      } else if (isMax) {
                        textColor = isDark ? 'text-sky-400' : 'text-sky-700';
                      }
                      
                      return (
                        <td key={c.id} className={`p-4 border-b transition-colors ${isDark ? 'border-slate-800' : 'border-slate-100'} ${isMax ? (isDark ? 'bg-sky-950/10' : 'bg-sky-50') : ''}`}>
                          <div className="flex flex-col gap-2">
                            <span className={`text-lg font-black ${isNull ? 'text-slate-400' : textColor}`}>
                              {isNull ? 'N/A' : val}
                            </span>
                            {!isNull && (
                              <div className={`w-full h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
                                <div className={`${barColor} h-full transition-all duration-1000`} style={{ width: `${normalized}%` }} />
                              </div>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ComparisonView;
