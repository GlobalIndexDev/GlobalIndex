
import React from 'react';
import { Country, CountryIndexData } from '../types';
import { calculateOverallIndex, normalizeValue } from '../utils';
import { SOURCES } from '../constants';
import IndexRadarChart from './IndexRadarChart';

interface Props {
  country: Country;
  onClose: () => void;
  isDark?: boolean;
  globalAverages: Record<keyof CountryIndexData, number>;
}

const CountryProfile: React.FC<Props> = ({ country, onClose, isDark, globalAverages }) => {
  const { score, missingCount } = calculateOverallIndex(country.indices);
  const isHighOverall = score >= 70;
  const isLowOverall = score > 0 && score < 40;

  const profileInfo = [
    { label: "Official Name", value: country.officialName },
    { label: "Continent", value: country.continent },
    { label: "Capital", value: country.capital },
    { 
      label: "Head of State", 
      value: country.headOfState,
      wiki: country.headOfStateWiki 
    },
    ...(country.headOfGovernment ? [{ 
      label: "Head of Government", 
      value: country.headOfGovernment,
      wiki: country.headOfGovernmentWiki
    }] : []),
    { label: "Government Form", value: country.governmentForm },
  ];

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-300 ${isDark ? 'bg-slate-950/80' : 'bg-slate-900/60'}`}>
      <div className={`w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl relative animate-in slide-in-from-bottom-4 duration-500 transition-colors ${isDark ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}`}>
        <button 
          onClick={onClose}
          className={`absolute top-6 right-6 p-2 rounded-full transition-colors z-10 ${isDark ? 'hover:bg-slate-800 text-slate-500 hover:text-white' : 'hover:bg-slate-100 text-slate-400 hover:text-slate-600'}`}
        >
          <i className="fas fa-times text-xl"></i>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Left Column: Info */}
          <div className="lg:col-span-7 p-8 md:p-12 space-y-8">
            <div className="flex items-center gap-6 border-b pb-8 border-slate-700/50">
              <img src={country.flag} alt={country.name} className={`w-24 h-16 object-cover rounded-xl shadow-md border ${isDark ? 'border-slate-800' : 'border-slate-100'}`} />
              <div>
                <h2 className="text-5xl font-black italic">{country.name}</h2>
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-lg font-bold ${isHighOverall ? 'text-emerald-500' : isLowOverall ? 'text-red-500' : isDark ? 'text-sky-400' : 'text-sky-600'}`}>
                    Overall Index Score: {score > 0 ? score.toFixed(1) : 'N/A'}
                  </span>
                  {missingCount > 0 && (
                    <span className={`text-xs px-3 py-1 rounded-full font-bold ${isDark ? 'bg-red-950/40 text-red-400' : 'bg-red-100 text-red-700'}`}>
                      ({missingCount}) missing
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {profileInfo.map((info, idx) => (
                <div key={idx} className={`p-4 rounded-xl border transition-colors ${isDark ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
                  <h4 className="text-xs font-bold uppercase tracking-widest opacity-40 mb-1">{info.label}</h4>
                  {(info as any).wiki ? (
                    <a 
                      href={(info as any).wiki} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sky-500 font-bold hover:underline flex items-center gap-2"
                    >
                      {info.value}
                      <i className="fas fa-external-link-alt text-[10px]"></i>
                    </a>
                  ) : (
                    <p className="font-bold opacity-90">{info.value}</p>
                  )}
                </div>
              ))}
            </div>

            <div className={`p-4 rounded-xl border border-dashed text-center ${isDark ? 'bg-slate-800/20 border-slate-700 text-slate-600' : 'bg-slate-100/50 border-slate-200 text-slate-400'}`}>
              <p className="text-[10px] font-bold uppercase tracking-widest">
                Data Verification: <a href="https://www.fao.org/member-countries/en/" target="_blank" className="text-sky-500 hover:underline">FAO</a> & <a href="https://www.wikipedia.org/" target="_blank" className="text-sky-500 hover:underline">Wikipedia</a>
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-black text-2xl opacity-90 italic">Metric Breakdown</h4>
              <div className="grid grid-cols-1 gap-4">
                {SOURCES.filter(s => s.key !== 'freedom' || (s.name !== 'Country Profile Data (FAO Members)' && s.name !== 'General Knowledge & Profiles (Wikipedia)')).map(source => {
                  const val = country.indices[source.key];
                  const isNull = val === null || val === undefined;
                  const normalized = isNull ? 0 : normalizeValue(source.key, val!);
                  
                  // Highlight logic based on fixed thresholds
                  const isBelowAverage = !isNull && normalized < 40;
                  const isAboveAverage = !isNull && normalized >= 70;
                  
                  let scoreColorClass = isDark ? 'text-sky-400' : 'text-sky-600';
                  let barColorClass = 'bg-sky-500';
                  let labelTag = null;

                  if (isAboveAverage) {
                    scoreColorClass = 'text-emerald-500';
                    barColorClass = 'bg-emerald-500';
                    labelTag = <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500">Above Avg</span>;
                  } else if (isBelowAverage) {
                    scoreColorClass = 'text-red-500';
                    barColorClass = 'bg-red-500';
                    labelTag = <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-red-500/10 text-red-500">Below Avg</span>;
                  }

                  return (
                    <div key={source.name} className={`p-5 border rounded-xl shadow-sm transition-colors ${isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="opacity-70 font-bold">{source.name.split(' (')[0]}</span>
                        <div className="flex items-center gap-3">
                           {labelTag}
                           <span className={`text-xl font-black ${isNull ? 'text-slate-400' : scoreColorClass}`}>
                             {isNull ? 'N/A' : val}
                           </span>
                        </div>
                      </div>
                      {!isNull ? (
                        <div className={`w-full h-2 rounded-full overflow-hidden ${isDark ? 'bg-slate-950' : 'bg-slate-100'}`}>
                          <div 
                            className={`${barColorClass} h-full transition-all duration-1000`} 
                            style={{ width: `${normalized}%` }}
                          />
                        </div>
                      ) : (
                        <p className="text-slate-400 text-xs font-bold uppercase tracking-wider italic">No empirical data available for this nation.</p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Visualization */}
          <div className={`lg:col-span-5 p-8 lg:p-12 flex flex-col items-center justify-center border-l transition-colors ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
            <div className="sticky top-12 text-center w-full">
              <h4 className="text-xl font-black mb-6 uppercase tracking-wider opacity-80 italic">Statistical Visualization</h4>
              <div className="w-full max-w-sm mx-auto aspect-square">
                <IndexRadarChart data={country.indices} isDark={isDark} />
              </div>
              <div className="mt-8 text-[11px] opacity-40 max-w-xs mx-auto leading-relaxed italic">
                <p className="font-bold uppercase tracking-widest text-sky-500">Web Chart (0-100)</p>
                <p className="mt-2">A comparison of national performance versus the highest possible values.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CountryProfile;
