
export interface CountryIndexData {
  freedom: number | null;
  democracy: number | null;
  safety: number | null;
  costOfLiving: number | null;
  healthCare: number | null;
  education: number | null;
  civilLiberty: number | null;
}

export interface Country {
  id: string;
  name: string;
  officialName: string;
  continent: string;
  capital: string;
  headOfState: string;
  headOfStateWiki?: string;
  headOfGovernment?: string;
  headOfGovernmentWiki?: string;
  governmentForm: string;
  code: string;
  flag: string;
  indices: CountryIndexData;
  description: string;
}

export interface IndexSource {
  name: string;
  url: string;
  key: keyof CountryIndexData;
}
